COVID-19 Hidden Markov Model
This code implements a Hidden Markov Model (HMM) to predict the outcome of COVID-19 infection rates and death rates based on historical data. The code is designed to run on Google Colab.

Prerequisites
Google Colab Account: Ensure you have a Google Colab account as this code is designed to run on this platform.

Dataset: The code requires COVID-19 datasets, including time_series_covid19_confirmed_US.csv and time_series_covid19_deaths_US.csv. These datasets should be uploaded to your Google Drive.

GITHUB LINK:-https://github.com/annadi006/Forecasting-COVID-19-Transmission-Patterns-with-Hidden-Markov-Model/tree/main


Steps to Run
1)Open Google Colab:

2)Open Google Colab in your web browser.
Mount Google Drive:

3)Run the first code cell to mount your Google Drive. This will prompt you to authenticate and provide a link to enter an authentication code.
Upload Datasets:

4)Upload the COVID-19 datasets (time_series_covid19_confirmed_US.csv and time_series_covid19_deaths_US.csv) to your Google Drive.
Run the Code:

5)Run each code cell in the provided Jupyter notebook on Google Colab. You can do this by clicking the play button on each cell or by selecting "Runtime" and then "Run all."
Visualizations:

6)Observe the visualizations of COVID-19 infection rates and death rates for different cities in the U.S.
Hidden Markov Model:

7)The code implements a Hidden Markov Model to predict the outcome of infection rates and death rates for different components.
Outcome Scores:

8)Review the outcome scores for the first 50, 100, and 200 days.
Log Likelihood:

9)The log likelihood of the HMM model on the test dataset is printed at the end.



Note
Ensure the datasets are available in the specified Google Drive path.
The code uses the hmmlearn library, so ensure it is installed using !pip install hmmlearn.
File Structure
time_series_covid19_confirmed_US.csv: Dataset containing COVID-19 confirmed cases.
time_series_covid19_deaths_US.csv: Dataset containing COVID-19 death cases.
Hidden_Markov_Model.ipynb: Jupyter notebook with the code for the Hidden Markov Model.